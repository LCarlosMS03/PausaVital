﻿using System;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;
using PausaVital.Services;

namespace PausaVital.Views
{
    public partial class MainWindow : Window
    {
        private readonly ApiService apiService;
        private readonly BackendProcessManager backendProcessManager;
        private readonly DispatcherTimer idleTimer;
        private readonly DispatcherTimer reconnectTimer;
        private readonly DispatcherTimer hydrationTimer;
        private readonly BreakManager breakManager;
        private DateTime lastTickTime = DateTime.UtcNow;

        private bool isResting = false;
        private int restSecondsRemaining = 0;
        private int restDurationSeconds = 20;

        public int currentUserId { get; private set; } = 0;
        private int currentHabitId = 0;

        private int cachedStreak = 0;
        private int cachedShields = 0;

        public bool IsShuttingDown { get; set; } = false;
        private bool hasShownMinimizeNotification = false;
        private string connectionStatusKey = "Starting";
        private string connectionStatusDefaultText = "Starting connection...";
        private System.Windows.Media.Brush connectionStatusColor = System.Windows.Media.Brushes.Goldenrod;

        public MainWindow()
        {
            InitializeComponent();

            TranslationManager.Initialize();
            ApplyStaticTranslations();

            apiService = new ApiService();
            ;
            backendProcessManager = new BackendProcessManager(apiService);
            breakManager = new BreakManager();

            Loaded += OnMainWindowLoaded;
            Closed += OnMainWindowClosed;

            Closing += OnMainWindowClosing;
            StateChanged += OnWindowStateChanged;

            reconnectTimer = new DispatcherTimer
            {
                Interval = TimeSpan.FromSeconds(15)
            };
            reconnectTimer.Tick += OnReconnectTimerTicked;

            // Setup hydration timer to tick every 1 hour
            hydrationTimer = new DispatcherTimer
            {
                Interval = TimeSpan.FromHours(1)
            };
            hydrationTimer.Tick += OnHydrationTimerTicked;
            hydrationTimer.Start();

            idleTimer = new DispatcherTimer
            {
                Interval = TimeSpan.FromSeconds(1)
            };
            idleTimer.Tick += OnIdleTimerTicked;
            idleTimer.Start();
        }

        private void OnWindowStateChanged(object? sender, EventArgs e)
        {
            if (WindowState == WindowState.Minimized)
            {
                Hide();
            }
        }

        private void OnMainWindowClosing(object? sender, System.ComponentModel.CancelEventArgs e)
        {
            if (IsShuttingDown) return;

            e.Cancel = true;

            var prefs = PreferencesManager.Load();

            if (prefs.CloseAction == "Minimize")
            {
                ExecuteHideToTray();
                return;
            }
            if (prefs.CloseAction == "Exit")
            {
                IsShuttingDown = true;
                System.Windows.Application.Current.Shutdown();
                return;
            }

            var prompt = new ClosePromptWindow { Owner = this };
            if (prompt.ShowDialog() == true)
            {
                if (prompt.SelectedAction == "Minimize")
                {
                    ExecuteHideToTray();
                }
                else if (prompt.SelectedAction == "Exit")
                {
                    IsShuttingDown = true;
                    System.Windows.Application.Current.Shutdown();
                }
            }
        }

        private void ExecuteHideToTray()
        {
            Hide();
            if (!hasShownMinimizeNotification)
            {
                App.TrayManager?.ShowNotification(
                    "Pausa Vital",
                    TranslationManager.Get("RunningBackground", "Running in background. Right-click tray icon to exit."));
                hasShownMinimizeNotification = true;
            }
        }

        private void OnHideToTrayButtonClicked(object sender, RoutedEventArgs e)
        {
            ExecuteHideToTray();
        }

        private async void OnMainWindowLoaded(object sender, RoutedEventArgs e)
        {
            TranslationManager.Initialize();

            var prefs = PreferencesManager.Load();
            if (string.IsNullOrEmpty(prefs.SelectedMode) || prefs.SelectedMode == "None")
            {
                var modeWindow = new ModeSelectionWindow { Owner = this };
                modeWindow.ShowDialog();
                prefs = PreferencesManager.Load();
            }

            string mode = prefs.SelectedMode == "Pomodoro" ? "Pomodoro" : "20-20-20";
            breakManager.SetMode(mode);
            restDurationSeconds = mode == "Pomodoro" ? 300 : 20;

            if (HideToBackgroundButton != null)
            {
                HideToBackgroundButton.Content = TranslationManager.Get("HideToBackgroundBtn", "Hide to Background");
            }

            if (LangToggleButton != null)
            {
                LangToggleButton.Content = prefs.Language == "en" ? "🌐 EN" : "🌐 ES";
            }

            UpdateConnectionUI("Starting", "Starting connection...", System.Windows.Media.Brushes.Goldenrod);

            bool isConnected = await backendProcessManager.EnsureBackendIsRunningAsync();
            await UpdateConnectionStatusAsync(isConnected);
        }

        private async void OnReconnectTimerTicked(object? sender, EventArgs e)
        {
            reconnectTimer.Stop();
            UpdateConnectionUI("Retrying", "Retrying connection...", System.Windows.Media.Brushes.Goldenrod);

            bool isConnected = await backendProcessManager.EnsureBackendIsRunningAsync();
            await UpdateConnectionStatusAsync(isConnected);
        }

        private void OnHydrationTimerTicked(object? sender, EventArgs e)
        {
            App.TrayManager?.ShowNotification(
                "Hydration Reminder",
                "Time to drink a glass of water to stay healthy and focused!");
        }

        private void ApplyStaticTranslations()
        {
            var prefs = PreferencesManager.Load();
            TranslationManager.CurrentLanguage = prefs.Language;

            WorkTimeLabel.Text = TranslationManager.Get("WorkTimeLabel", "WORK TIME");

            StreakText.Text = $"{TranslationManager.Get("Streak", "🔥 Streak:")} {cachedStreak}";
            ShieldsText.Text = $"{TranslationManager.Get("Shields", "🛡️ Shields:")} {cachedShields}";

            HideToBackgroundButton.Content = TranslationManager.Get("HideToBackgroundBtn", "Hide to Background");

            LangToggleButton.Content = prefs.Language == "en" ? "🌐 EN" : "🌐 ES";

            if (isResting)
            {
                RestStatusText.Text = $"{TranslationManager.Get("Resting", "RESTING... DO NOT MOVE!")} ({restSecondsRemaining}s)";
            }

            RefreshConnectionUI();
        }

        private void RefreshConnectionUI()
        {
            ConnectionStatusText.Text = TranslationManager.Get(connectionStatusKey, connectionStatusDefaultText);
            ConnectionStatusDot.Fill = connectionStatusColor;
        }

        private void UpdateConnectionUI(string key, string defaultText, System.Windows.Media.Brush color)
        {
            connectionStatusKey = key;
            connectionStatusDefaultText = defaultText;
            connectionStatusColor = color;

            RefreshConnectionUI();
        }

        private async Task UpdateConnectionStatusAsync(bool isConnected)
        {
            if (isConnected)
            {
                reconnectTimer.Stop();
                UpdateConnectionUI(
                    "Connected",
                    "Connected",
                    System.Windows.Media.Brushes.MediumSeaGreen);

                currentUserId = await apiService.LoginAsync(Environment.UserName);
                currentHabitId = await apiService.GetDefaultHabitAsync();

                await UpdateStreakAndShieldsAsync();
            }
            else
            {
                UpdateConnectionUI(
                    "Disconnected",
                    "Disconnected. Retrying...",
                    System.Windows.Media.Brushes.IndianRed);

                reconnectTimer.Start();
            }
        }

        private async Task UpdateStreakAndShieldsAsync()
        {
            if (currentUserId == 0) return;

            cachedStreak = await apiService.GetCurrentStreakAsync(currentUserId);
            StreakText.Text = $"{TranslationManager.Get("Streak", "🔥 Streak:")} {cachedStreak}";

            cachedShields = await apiService.GetShieldsAsync(currentUserId);
            ShieldsText.Text = $"{TranslationManager.Get("Shields", "🛡️ Shields:")} {cachedShields}";
        }

        private async void OnIdleTimerTicked(object? sender, EventArgs e)
        {
            DateTime now = DateTime.UtcNow;
            TimeSpan elapsed = now - lastTickTime;
            lastTickTime = now;

            TimeSpan idleTime = ActivityMonitor.GetIdleTime();

            if (isResting)
            {
                if (idleTime.TotalSeconds < 1.0)
                {
                    await HandleFailedRestAsync();
                }
                else
                {
                    restSecondsRemaining--;
                    RestStatusText.Text = $"{TranslationManager.Get("Resting", "RESTING... DO NOT MOVE!")} ({restSecondsRemaining}s)";

                    App.TrayManager?.UpdateText($"Resting: {restSecondsRemaining}s left");

                    if (restSecondsRemaining <= 0)
                    {
                        await HandleSuccessfulRestAsync();
                    }
                }
                return;
            }

            TimeSpan currentWork = breakManager.WorkTime;
            WorkTimeText.Text = $"{currentWork.Minutes:D2}:{currentWork.Seconds:D2}";

            string trayHoverText = $"Work: {currentWork.Minutes:D2}:{currentWork.Seconds:D2} | Streak: {cachedStreak}";
            App.TrayManager?.UpdateText(trayHoverText);

            if (breakManager.ShouldTakeBreak(idleTime, elapsed))
            {
                StartRestMode();
            }
        }

        private void StartRestMode()
        {
            isResting = true;
            restSecondsRemaining = restDurationSeconds;

            RestStatusText.Visibility = Visibility.Visible;
            RestStatusText.Text = $"{TranslationManager.Get("Resting", "RESTING... DO NOT MOVE!")} ({restSecondsRemaining}s)";
            RestStatusText.Foreground = System.Windows.Media.Brushes.DarkOrange;

            string tip = GetBreakTip();

            App.TrayManager?.ShowNotification(
                TranslationManager.Get("BreakTitle", "Break Time"),
                tip);
        }

        private async Task HandleSuccessfulRestAsync()
        {
            isResting = false;
            RestStatusText.Visibility = Visibility.Collapsed;

            if (currentUserId == 0 || currentHabitId == 0)
            {
                App.TrayManager?.ShowNotification(
                    "Pausa Vital",
                     TranslationManager.Get("BackendNotReady", "Backend is not ready yet."));
            }

            bool recorded = await apiService.RecordBreakAsync(currentUserId, currentHabitId, "completed");
            if (recorded)
            {
                await UpdateStreakAndShieldsAsync();
                App.TrayManager?.ShowNotification(
                    TranslationManager.Get("BreakCompletedTitle", "Break Completed"),
                    TranslationManager.Get("BreakCompletedMessage", "Great job! Streak updated."));
            }
        }

        private async Task HandleFailedRestAsync()
        {
            isResting = false;

            if (currentUserId == 0 || currentHabitId == 0)
            {
                RestStatusText.Visibility = Visibility.Collapsed;
                return;
            }

            bool shieldConsumed = await apiService.ConsumeShieldAsync(currentUserId);

            if (shieldConsumed)
            {
                RestStatusText.Text = TranslationManager.Get("Saved", "SAVED BY SHIELD!");
                RestStatusText.Foreground = System.Windows.Media.Brushes.DodgerBlue;

                App.TrayManager?.ShowNotification(
                    TranslationManager.Get("ShieldUsedTitle", "Shield Used!"),
                    TranslationManager.Get("ShieldUsedMessage", "You moved, but a shield saved your streak!"));
            }
            else
            {
                RestStatusText.Text = TranslationManager.Get("Broken", "STREAK BROKEN!");
                RestStatusText.Foreground = System.Windows.Media.Brushes.Red;

                App.TrayManager?.ShowNotification(
                    TranslationManager.Get("StreakBrokenTitle", "Streak Broken"),
                    TranslationManager.Get("StreakBrokenMessage", "You moved before the 20 seconds were up!"));
            }

            await UpdateStreakAndShieldsAsync();

            await Task.Delay(3000);
            if (!isResting)
            {
                RestStatusText.Visibility = Visibility.Collapsed;
            }
        }

        private void OnMainWindowClosed(object? sender, EventArgs e)
        {
            idleTimer.Stop();
            reconnectTimer.Stop();
            hydrationTimer.Stop(); // Clean up hydration timer to prevent memory leaks
            backendProcessManager.Dispose();
        }

        private async void OnLangToggleClicked(object sender, RoutedEventArgs e)
        {
            var prefs = PreferencesManager.Load();

            prefs.Language = prefs.Language == "en" ? "es" : "en";
            PreferencesManager.Save(prefs);

            TranslationManager.CurrentLanguage = prefs.Language;

            ApplyStaticTranslations();
            App.TrayManager?.RefreshTexts();

            if (currentUserId != 0)
            {
                await UpdateStreakAndShieldsAsync();
            }
        }

        private string GetBreakTip()
        {
            return restDurationSeconds == 300
                ? TranslationManager.Get("PomodoroTip", "Time for a 5-minute break! Stand up and stretch.")
                : TranslationManager.Get("RuleTip", "Look away for 20 seconds! Do not touch the mouse or keyboard.");
        }
    }
}